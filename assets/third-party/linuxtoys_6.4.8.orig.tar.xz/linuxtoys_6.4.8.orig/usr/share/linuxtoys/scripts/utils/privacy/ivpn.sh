#!/bin/bash
# name: IVPN
# version: 1.0
# description: IVPN
# icon: ivpn.svg
# compat: ubuntu, debian, fedora, ostree, ublue, rhel
# repo: https://www.ivpn.net

# --- Start of the script code ---
source "$SCRIPT_DIR/libs/linuxtoys.lib"
_lang_
sudo_rq
if is_debian; then
	# Add IVPN's GPG key
	curl -fsSL https://repo.ivpn.net/stable/debian/generic.gpg | gpg --dearmor | sudo tee /usr/share/keyrings/ivpn-archive-keyring.gpg > /dev/null
	sudo chown root:root /usr/share/keyrings/ivpn-archive-keyring.gpg && sudo chmod 644 /usr/share/keyrings/ivpn-archive-keyring.gpg
	# Add the IVPN repository
	curl -fsSL https://repo.ivpn.net/stable/debian/generic.list | sudo tee /etc/apt/sources.list.d/ivpn.list
	sudo chown root:root /etc/apt/sources.list.d/ivpn.list && sudo chmod 644 /etc/apt/sources.list.d/ivpn.list
	# Update APT repo info
	sudo apt update
elif is_ubuntu; then
	# Add IVPN's GPG key
	curl -fsSL https://repo.ivpn.net/stable/ubuntu/generic.gpg | gpg --dearmor | sudo tee /usr/share/keyrings/ivpn-archive-keyring.gpg > /dev/null
	sudo chown root:root /usr/share/keyrings/ivpn-archive-keyring.gpg && sudo chmod 644 /usr/share/keyrings/ivpn-archive-keyring.gpg
	# Add the IVPN repository
	curl -fsSL https://repo.ivpn.net/stable/ubuntu/generic.list | sudo tee /etc/apt/sources.list.d/ivpn.list
	sudo chown root:root /etc/apt/sources.list.d/ivpn.list && sudo chmod 644 /etc/apt/sources.list.d/ivpn.list
	# Update APT repo info
	sudo apt update
elif is_fedora || is_ostree || is_rhel; then
	if is_ostree; then
		prep_tmp
		wget https://repo.ivpn.net/stable/fedora/generic/ivpn.repo
		sudo install -o root -g root -m 644 ivpn.repo /etc/yum.repos.d/
		rpm-ostree refresh-md
	else
		sudo dnf config-manager addrepo --from-repofile=https://repo.ivpn.net/stable/fedora/generic/ivpn.repo
	fi
fi
pkg_install ivpn-ui
