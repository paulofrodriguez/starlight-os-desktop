#!/bin/bash
# name: DaVinci Resolve
# version: 1.0
# description: davinci_desc
# icon: resolve.svg

# functions
#create JSON, user agent and download Resolve
getresolve () {
  	local pkgname="$_upkgname"
  	local _product=""
  	local _referid=""
  	local _siteurl=""
  	_archive_name=""
  	_archive_run_name=""

  	if [ "$pkgname" == "davinci-resolve" ]; then
    		_product="DaVinci Resolve"
    		_referid='dfd43085ef224766b06b579ce8a6d097'
    		_siteurl="https://www.blackmagicdesign.com/api/support/latest-stable-version/davinci-resolve/linux"
            local _useragent="User-Agent: Mozilla/5.0 (X11; Linux ${CARCH}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.75 Safari/537.36"
  	        local _releaseinfo
  	        _releaseinfo=$(curl -Ls "$_siteurl")
            _pkgver=$(printf "%s" "$_releaseinfo" | awk -F'[,:]' '{for(i=1;i<=NF;i++){if($i~/"major"/){print $(i+1)} if($i~/"minor"/){print $(i+1)} if($i~/"releaseNum"/){print $(i+1)}}}' | sed 'N;s/\n/./;N;s/\n/./')
            _releaseNum=$(printf "%s" "$_releaseinfo" | awk -F'[,:]' '{for(i=1;i<=NF;i++){if($i~/"releaseNum"/){print $(i+1)}}}')
            if [ "$_releaseNum" == "0" ]; then
                _filever=$(printf "%s" "$_releaseinfo" | awk -F'[,:]' '{for(i=1;i<=NF;i++){if($i~/"major"/){print $(i+1)} if($i~/"minor"/){print $(i+1)}}' | sed 'N;s/\n/./')
            else
                _filever="${_pkgver}"
            fi
    		_archive_name="DaVinci_Resolve_${_filever}_Linux"
    		_archive_run_name="DaVinci_Resolve_${_filever}_Linux"
  	elif [ "$pkgname" == "davinci-resolve-studio" ]; then
    		_product="DaVinci Resolve Studio"
    		_referid='0978e9d6e191491da9f4e6eeeb722351'
    		_siteurl="https://www.blackmagicdesign.com/api/support/latest-stable-version/davinci-resolve-studio/linux"
            local _useragent="User-Agent: Mozilla/5.0 (X11; Linux ${CARCH}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.75 Safari/537.36"
  	        local _releaseinfo
  	        _releaseinfo=$(curl -Ls "$_siteurl")
            _pkgver=$(printf "%s" "$_releaseinfo" | awk -F'[,:]' '{for(i=1;i<=NF;i++){if($i~/"major"/){print $(i+1)} if($i~/"minor"/){print $(i+1)} if($i~/"releaseNum"/){print $(i+1)}}}' | sed 'N;s/\n/./;N;s/\n/./')
            _releaseNum=$(printf "%s" "$_releaseinfo" | awk -F'[,:]' '{for(i=1;i<=NF;i++){if($i~/"releaseNum"/){print $(i+1)}}}')
            if [ "$_releaseNum" == "0" ]; then
                _filever=$(printf "%s" "$_releaseinfo" | awk -F'[,:]' '{for(i=1;i<=NF;i++){if($i~/"major"/){print $(i+1)} if($i~/"minor"/){print $(i+1)}}}' | sed 'N;s/\n/./')
            else
                _filever="${_pkgver}"
            fi
    		_archive_name="DaVinci_Resolve_Studio_${_filever}_Linux"
    		_archive_run_name="DaVinci_Resolve_Studio_${_filever}_Linux"
  	fi

  	local _downloadId
  	_downloadId=$(printf "%s" "$_releaseinfo" | sed -n 's/.*"downloadId":"\([^"]*\).*/\1/p')

  	# Optional version check - uncomment if needed
  	# if [[ $_expected_pkgver != "$_pkgver" ]]; then
    	# 	echo "Version mismatch"
    	# 	return 1
  	# fi

  	local _reqjson
  	_reqjson="{\"firstname\": \"Arch\", \"lastname\": \"Linux\", \"email\": \"someone@archlinux.org\", \"phone\": \"202-555-0194\", \"country\": \"us\", \"street\": \"Bowery 146\", \"state\": \"New York\", \"city\": \"AUR\", \"product\": \"$_product\"}"
  	_reqjson=$(printf '%s' "$_reqjson" | sed 's/[[:space:]]\+/ /g')
  	_useragent=$(printf '%s' "$_useragent" | sed 's/[[:space:]]\+/ /g')
  	local _useragent_escaped="${_useragent// /\\ }"

  	_siteurl="https://www.blackmagicdesign.com/api/register/us/download/${_downloadId}"
  	local _srcurl
  	_srcurl=$(curl -s \
    		-H 'Host: www.blackmagicdesign.com' \
    		-H 'Accept: application/json, text/plain, */*' \
    		-H 'Origin: https://www.blackmagicdesign.com' \
    		-H "$_useragent" \
    		-H 'Content-Type: application/json;charset=UTF-8' \
    		-H "Referer: https://www.blackmagicdesign.com/support/download/${_referid}/Linux" \
    		-H 'Accept-Encoding: gzip, deflate, br' \
    		-H 'Accept-Language: en-US,en;q=0.9' \
    		-H 'Authority: www.blackmagicdesign.com' \
    		-H 'Cookie: _ga=GA1.2.1849503966.1518103294; _gid=GA1.2.953840595.1518103294' \
    		--data-ascii "$_reqjson" \
    		--compressed \
    		"$_siteurl")

	curl -L -o "${_archive_name}.zip" "$_srcurl"
}

# check if sufficient disk space is available
check_disk_space () {
	local pkgname="$1"
	local required_space_gb=0

	# set required space based on package type
	if [ "$pkgname" == "davinci-resolve" ]; then
		required_space_gb=12
	elif [ "$pkgname" == "davinci-resolve-studio" ]; then
		required_space_gb=25
	fi

	local required_space_kb=$((required_space_gb * 1024 * 1024))
	local home_available_kb=$(df "$HOME" | awk 'NR==2 {print $4}')
	local root_available_kb=$(df / | awk 'NR==2 {print $4}')

	# check home directory
	if [ "$home_available_kb" -lt "$required_space_kb" ]; then
		fatal "$outofspace"
	fi

	# check root filesystem
	if [ "$root_available_kb" -lt "$required_space_kb" ]; then
		fatal "$outofspace"
	fi
}

davincinatd () {
    { is_rhel && dv_rhel; } || true

    # opencl check for AMD/Intel GPUs
    if is_intel || is_amd; then
        if ! clinfo_chk; then
            fatal "$nocl"
        fi
    fi
    if is_debian || is_ubuntu; then
        curl -L -o autoresolvedeb.sh "https://raw.githubusercontent.com/psygreg/autoresolvedeb/main/linuxtoys/autoresolvedeb.sh"
        chmod +x autoresolvedeb.sh
        ./autoresolvedeb.sh
        rm autoresolvedeb.sh
#    elif is_arch || is_cachy; then
#        curl -L -o autoresolvepkg.sh "https://raw.githubusercontent.com/psygreg/autoresolvedeb/main/linuxtoys/autoresolvepkg.sh"
#        chmod +x autoresolvepkg.sh
#        ./autoresolvepkg.sh
#        rm autoresolvepkg.sh
    elif is_fedora; then
        curl -L -o autoresolverpm.sh "https://raw.githubusercontent.com/psygreg/autoresolvedeb/main/linuxtoys/autoresolverpm.sh"
        chmod +x autoresolverpm.sh
        ./autoresolverpm.sh
        rm autoresolverpm.sh
    elif is_suse; then
        curl -L -o autoresolverpm.sh "https://raw.githubusercontent.com/psygreg/autoresolvedeb/main/linuxtoys/autoresolverpm.sh"
        chmod +x autoresolverpm.sh
        ./autoresolverpm.sh
        rm autoresolverpm.sh
    fi
}

davinciboxd () {    
    curl -L -o autodavincibox.sh "https://raw.githubusercontent.com/psygreg/autoresolvedeb/main/linuxtoys/autodavincibox.sh"
    chmod +x autodavincibox.sh
    ./autodavincibox.sh
    rm autodavincibox.sh
}

dv_rhel () {
    dv_rhel_in () {
        check_disk_space "$_upkgname"
        sudo_rq
        rpmfusion_chk # needs EPEL

        # dependencies -- compile python2
        sudo dnf groupinstall -y "Development Tools"
        pkg_install gcc openssl-devel bzip2-devel libffi-devel wget tar curl
        prep_tmp_noram
        wget "https://www.python.org/ftp/python/2.7.18/Python-2.7.18.tgz" || fatal "unable to get dependency python2"
        tar xzf Python-2.7.18.tgz && cd Python-2.7.18
        export CFLAGS="-std=c11"
        ./configure --with-system-ffi --with-computed-gotos --enable-optimizations --enable-unicode=ucs4
        make -j$(nproc) build_all
        sudo make altinstall
        sudo ln -s /usr/local/bin/python2.7 /usr/local/bin/python2
        { which python2 &>/dev/null && echo "Python2 installation successful. Proceeding to Resolve installation."; } || fatal "Dependency python2 installation failed."

        # resolve dependencies
        pkg_install qt5-qtbase-gui libxcb glib2 apr-util mesa-libGLU libxcrypt-compat zlib-ng zlib-ng-compat
        { is_amd && pkg_install rocm-comgr rocm-runtime rccl rocalution rocblas rocfft rocm-smi rocsolver rocsparse rocm-device-libs rocminfo rocm-hip hiprand rocm-opencl clinfo && sudo usermod -aG render,video "$USER"; } || true
        { is_intel && pkg_install intel-compute-runtime; } || true
        {( is_nvidia && ( rpm -qi "cuda" &>/dev/null || rpm -qi "cuda-drivers" &>/dev/null )) || fatal "Missing cuda drivers. Please install them from the Drivers menu according to your GPU."; } || true

        # install resolve
        getresolve
        unzip "$_archive_name.zip"
        prep_dir /opt/resolve
        chmod +x ${_archive_run_name}.run
        export SKIP_PACKAGE_CHECK=1
        ./${_archive_run_name}.run || fatal "Failed to install Resolve"
        # libs patch
        sudo_rq
        sudo mkdir -p /opt/resolve/libs/disabled
        move_ /opt/resolve/libs/libglib* /opt/resolve/libs/disabled/
        move_ /opt/resolve/libs/libgio* /opt/resolve/libs/disabled/
        move_ /opt/resolve/libs/libgmodule* /opt/resolve/libs/disabled/

        zeninf "$finishmsg"
    }

    while true; do
		CHOICE=$(zenity --list --title="DaVinci Resolve installer for RHEL" \
        	--column="Which version do you want to install?" \
			"Free" \
			"Studio" \
			"$msg070" \
			--height=300 --width=300)

		if [ $? -ne 0 ]; then
        	break
   		fi

		case $CHOICE in
			"Free") _upkgname='davinci-resolve'
    			dv_rhel_in
				break ;;
			"Studio") _upkgname='davinci-resolve-studio'
	  			dv_rhel_in
    			break ;;
			"$msg070") break && return 100;;
			*) echo "Invalid Option" ;;
		esac
	done
}

davinciboxatom () {

    dv_atom_deps () {
        pkg_install --ostreecheck toolbox podman lshw
        if is_nvidia; then
            pkg_install curl
			curl -s -L -k https://nvidia.github.io/libnvidia-container/stable/rpm/nvidia-container-toolkit.repo | \
  				sudo tee /etc/yum.repos.d/nvidia-container-toolkit.repo
            pkg_install --ostreecheck nvidia-container-toolkit nvidia-container-toolkit-base libnvidia-container-tools libnvidia-container1
        fi
    }

    # installation
    dv_atom_in () {
        check_disk_space "$_upkgname"
        sudo_rq  
        dv_atom_deps
        git clone https://github.com/zelikos/davincibox.git
        sleep 1
        cd davincibox
        getresolve
        unzip "$_archive_name.zip"
        chmod +x setup.sh
        if ./setup.sh "$_archive_run_name.run"; then
            distrobox_created davincibox
        else
            fatal "Failed to create DaVinciBox container."
        fi
	    zenity --info --title "AutoDaVinciBox" --text "Installation successful." --height=300 --width=300
        # set up ROCm inside davincibox for a sizable performance increase for AMD GPUs
        if is_amd; then
            distrobox enter davincibox -- bash -c "sudo dnf install -y rocm-comgr rocm-runtime rccl rocalution rocblas rocfft rocm-smi rocsolver rocsparse rocm-device-libs rocminfo rocm-hip hiprand rocm-opencl clinfo && sudo usermod -aG render,video \$USER"
            # stop to ensure usermod takes effect before usage of the software
            distrobox stop davincibox
        fi
        cd $HOME
        sudo rm -rf davincibox #cleanup
        zeninf "$finishmsg"
    }

	while true; do
		CHOICE=$(zenity --list --title="AutoDaVinciBox" \
        	--column="Which version do you want to install?" \
			"Free" \
			"Studio" \
			"$msg070" \
			--height=300 --width=300)

		if [ $? -ne 0 ]; then
        	break
   		fi

		case $CHOICE in
			"Free") _upkgname='davinci-resolve'
    			dv_atom_in
				break ;;
			"Studio") _upkgname='davinci-resolve-studio'
	  			dv_atom_in
    			break ;;
			"$msg070") break && return 100;;
			*) echo "Invalid Option" ;;
		esac
	done
}
# if on atomic distros, go straight to davincibox
source "$SCRIPT_DIR/libs/helpers.lib"
_lang_
# warn about just installing Resolve, and still requiring a purchase from BMD to use Studio
zenwrn "$msg034"
cd $HOME
export SCRIPT_DIR
if is_ostree; then
    davinciboxatom
elif is_solus || is_arch || is_cachy || is_ubuntu; then
    davinciboxd
else
    # menu
    while true; do

        CHOICE=$(zenity --list --title "DaVinci Resolve" \
            --column="" \
            "$msg231" \
            "$msg232" \
            "$msg070" \
            --height=330 --width=300)

        if [ $? -ne 0 ]; then
            break
        fi

        case $CHOICE in
        "$msg231") davinciboxd && break ;;
        "$msg232") davincinatd && break ;;
        "$msg070") break && exit 100;;
        *) echo "Invalid Option" ;;
        esac

    done
fi
