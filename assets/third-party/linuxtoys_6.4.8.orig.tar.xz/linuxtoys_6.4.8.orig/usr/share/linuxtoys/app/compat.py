def is_containerized():
    """
    Detect if the system is running inside a container.

    This function checks multiple indicators to determine if the system
    is running in a containerized environment such as Docker, Podman, LXC, etc.

    In developer mode:
    - If CONTAINER=1 is set, simulate being in a container (return True)
    - If CONTAINER is not set, use actual container detection

    Detection methods:
    1. Environment variables (container, CONTAINER_ID, DOCKER_CONTAINER, PODMAN_CONTAINER)
    2. Container-specific files (/.dockerenv, /run/.containerenv)
    3. cgroup analysis for container indicators
    4. systemd-detect-virt utility (if available)

    Returns:
        bool: True if containerized, False otherwise.
    """
    import os

    # Check for developer mode container simulation
    try:
        from .dev_mode import should_simulate_container

        if should_simulate_container():
            return True  # Simulate being in a container when CONTAINER=1
    except ImportError:
        # dev_mode not available, continue with normal behavior
        pass

    # Check for container environment variables
    container_env_vars = [
        "container",
        "CONTAINER_ID",
        "DOCKER_CONTAINER",
        "PODMAN_CONTAINER",
    ]

    for var in container_env_vars:
        if os.environ.get(var):
            return True

    # Check for container-specific files
    container_files = ["/.dockerenv", "/run/.containerenv"]

    for file_path in container_files:
        if os.path.exists(file_path):
            return True

    # Check cgroup for container indicators
    try:
        with open("/proc/1/cgroup", "r") as f:
            cgroup_content = f.read()
            container_indicators = ["docker", "lxc", "containerd", "podman"]
            for indicator in container_indicators:
                if indicator in cgroup_content:
                    return True
    except Exception:
        pass

    # Check for systemd-detect-virt (if available)
    try:
        result = os.system("command -v systemd-detect-virt >/dev/null 2>&1")
        if result == 0:
            # Run systemd-detect-virt --container
            exit_code = os.system("systemd-detect-virt --container >/dev/null 2>&1")
            if exit_code == 0:  # Returns 0 if in container
                return True
    except Exception:
        pass

    return False


def is_supported_system():
    """
    Check if the current system is supported by LinuxToys.

    A system is considered supported if it matches at least one of the
    supported OS compatibility keys (debian, ubuntu, cachy, arch, fedora, rhel, suse, ostree, ublue).

    In developer mode:
    - If COMPAT is set to simulate a specific system, that system's compatibility is checked
    - If COMPAT is not set (show all scripts), returns True (skip the check)

    Returns:
        bool: True if the system is supported, False otherwise
    """
    # Check if developer mode override is active
    try:
        from .dev_mode import get_dev_compat_override, is_dev_mode_enabled

        if is_dev_mode_enabled() and not get_dev_compat_override():
            # Developer mode without specific system simulation - skip check
            return True
    except ImportError:
        # dev_mode not available, continue with normal behavior
        pass

    # Explicitly block unsupported distributions
    os_release = {}
    try:
        with open("/etc/os-release", "r") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    os_release[k] = v.strip('"')
    except Exception:
        pass

    id_val = os_release.get("ID", "").lower()
    id_like = os_release.get("ID_LIKE", "").lower()

    # Block vanilla OS
    if id_val == "vanilla":
        return False

    # Block unsupported Ubuntu versions (only noble and resolute are supported)
    if id_val == "ubuntu":
        version_codename = os_release.get("VERSION_CODENAME", "").lower()
        if version_codename not in ["noble", "resolute"]:
            return False
    elif "ubuntu" in id_like:
        # For Ubuntu-based distros, check UBUNTU_CODENAME for supported versions
        ubuntu_codename = os_release.get("UBUNTU_CODENAME", "").lower()
        if ubuntu_codename not in ["noble", "resolute"]:
            return False

    # Get system compatibility keys
    compat_keys = get_system_compat_keys()

    # Define the set of supported OS compatibility keys
    supported_os_keys = {
        "debian",
        "ubuntu",
        "cachy",
        "arch",
        "fedora",
        "rhel",
        "suse",
        "ostree",
        "ublue",
        "zorin",
        "solus",
        "pika",
        "deepin"
    }

    # Check if any OS compatibility key matches
    return bool(compat_keys & supported_os_keys)


def get_system_compat_keys():
    """
    Get the system compatibility keys.

    In developer mode, this can be overridden to simulate different systems
    or show all scripts regardless of compatibility.

    Returns:
        set: Set of compatibility keys for the current system
               (OS keys: debian, ubuntu, cachy, arch, fedora, rhel, suse, ostree, ublue;
              GPU keys: gpu, gpu-amd, gpu-intel, gpu-nvidia;
              Desktop keys: desktop, desktop-gnome, desktop-plasma, desktop-other;
              Init keys: systemd;
              Session keys: x11, wayland)
    """
    # Check if developer mode override is active
    try:
        from .dev_mode import get_effective_compat_keys, is_dev_mode_enabled

        if is_dev_mode_enabled():
            return get_effective_compat_keys()
    except ImportError:
        # dev_mode not available, continue with normal behavior
        pass

    keys = set()
    os_release = {}
    try:
        with open("/etc/os-release", "r") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    os_release[k] = v.strip('"')
    except Exception:
        pass

    id_val = os_release.get("ID", "").lower()
    id_like = os_release.get("ID_LIKE", "").lower()
    is_rhel_family = (
        id_val in ["rhel", "centos", "almalinux"] or "rhel" in id_like
    )

    if (id_val in ["debian"] or id_val in ["deepin"] or "debian" in id_like) and (id_val not in ["ubuntu"] and "ubuntu" not in id_like):
        keys.add("debian")
    if id_val in ["ubuntu"]:
        # Only add ubuntu compat key for supported versions (noble, resolute)
        version_codename = os_release.get("VERSION_CODENAME", "").lower()
        if version_codename in ["noble", "resolute"]:
            keys.add("ubuntu")
    elif "ubuntu" in id_like:
        # For Ubuntu-based distros, check UBUNTU_CODENAME for supported versions
        ubuntu_codename = os_release.get("UBUNTU_CODENAME", "").lower()
        if ubuntu_codename in ["noble", "resolute"]:
            keys.add("ubuntu")
    if id_val in ["zorin"] or "zorin" in id_like:
        keys.add("zorin")
    if id_val in ["pika"]:
        keys.add("pika")
    if id_val in ["deepin"]:
        keys.add("deepin")
    if id_val in ["biglinux", "bigcommunity", "manjaro"] or "manjaro" in id_like:
        keys.add("manjaro")
    if id_val in ["cachyos"]:
        keys.add("cachy")
    if (
        id_val in ["arch", "archlinux", "artix"]
        or "arch" in id_like
        or "archlinux" in id_like
    ) and id_val != "cachyos":
        keys.add("arch")
    if is_rhel_family:
        keys.add("rhel")
    if id_val in ["fedora"] or ("fedora" in id_like and not is_rhel_family):
        keys.add("fedora")
    if id_val in ["suse", "opensuse"] or "suse" in id_like or "opensuse" in id_like:
        keys.add("suse")
    if id_val in ["solus"]:
        keys.add("solus")

    # Check for rpm-ostree immutable distros
    import os

    if os.system("command -v rpm-ostree >/dev/null 2>&1") == 0:
        if id_val in ["bazzite"] or id_val in ["bluefin"] or id_val in ["aurora"]:
            keys = {"ublue"}
        else:
            keys = {"ostree"}  # Override all other keys

    # Add GPU compatibility keys
    gpu_keys = get_gpu_compat_keys()
    keys.update(gpu_keys)

    # Add CPU compat keys
    cpu_keys = get_cpu_compat_keys()
    keys.update(cpu_keys)

    # Add desktop compatibility keys
    desktop_keys = get_desktop_compat_keys()
    keys.update(desktop_keys)

    # Add init system compatibility keys
    init_keys = get_init_compat_keys()
    keys.update(init_keys)

    # Add session type compatibility keys
    session_keys = get_current_session_type()
    keys.update(session_keys)

    return keys


def get_gpu_compat_keys():
    """
    Get the GPU compatibility keys based on detected GPUs.

    Returns:
        set: Set of GPU compatibility keys ('gpu', 'gpu-amd', 'gpu-intel', 'gpu-nvidia')
    """
    keys = set()
    try:
        import subprocess

        result = subprocess.run(["lspci"], capture_output=True, text=True, timeout=10)
        lspci_output = result.stdout.lower()

        has_amd = "radeon" in lspci_output or "rx" in lspci_output
        has_intel = False
        has_nvidia = "nvidia" in lspci_output

        # Check Intel GPU by ensuring 'intel' and ('vga' or '3d') are in the same line
        for line in lspci_output.split("\n"):
            if "intel" in line and ("vga" in line or "3d" in line):
                has_intel = True
                break

        if has_amd or has_intel or has_nvidia:
            keys.add("gpu")
        if has_amd:
            keys.add("gpu-amd")
        if has_intel:
            keys.add("gpu-intel")
        if has_nvidia:
            keys.add("gpu-nvidia")
    except Exception:
        pass
    return keys

def get_cpu_compat_keys():
    """
    Get the CPU compatibility keys based on detected CPU vendor.

    Returns:
        Single compatibility key 'intel' or 'amd', generic 'cpu' placeholder for default (no header, compatible with any CPU) scripts
    """
    keys = {"cpu"}
    try:
        vendor_id = None
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("vendor_id"):
                    vendor_id = line.split(":", 1)[1].strip()                    
                    if "GenuineIntel" in vendor_id:
                        keys.add("cpu-intel")
                    if "AuthenticAMD" in vendor_id:
                        keys.add("cpu-amd")
                    break

    except Exception:
        pass
    return keys

def get_desktop_compat_keys():
    """
    Get the desktop environment compatibility keys based on detected DE.

    Returns:
        set: Set of desktop compatibility keys ('desktop', 'desktop-gnome', 'desktop-plasma', 'desktop-other')
    """
    keys = set()
    import os

    desktop = os.environ.get("XDG_CURRENT_DESKTOP", "").upper()

    if desktop == "GNOME":
        keys.add("desktop-gnome")
    elif desktop == "KDE":
        keys.add("desktop-plasma")
    else:
        keys.add("desktop-other")

    if keys:
        keys.add("desktop")

    return keys


def is_systemd():
    """
    Detect if the system is running systemd as the init system.

    Detection method:
    1. Use 'ps 1' to get the init process name
    2. If it contains 'systemd', system is using systemd
    3. If it returns '/sbin/init', check if it's a symlink to systemd

    Returns:
        bool: True if systemd is the init system, False otherwise
    """
    import subprocess

    try:
        # Use ps -p 1 to get the init process
        result = subprocess.run(
            ["ps", "-p", "1", "-o", "comm="],
            capture_output=True,
            text=True,
            timeout=5
        )
        init_process = result.stdout.strip()

        # Check if process is systemd
        if "systemd" in init_process:
            return True

        # If it's /sbin/init, check if it's a symlink to systemd
        if init_process in ["/sbin/init", "init"]:
            try:
                # Check if /sbin/init is a symlink to systemd
                readlink_result = subprocess.run(
                    ["readlink", "/sbin/init"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                symlink_target = readlink_result.stdout.strip()
                if "systemd" in symlink_target:
                    return True
            except Exception:
                pass

    except Exception:
        pass

    return False


def get_init_compat_keys():
    """
    Get the init system compatibility keys based on detected init system.

    Returns:
        set: Set of init system compatibility keys ('systemd' if systemd is running, empty set otherwise)
    """
    keys = set()
    if is_systemd():
        keys.add("systemd")
    return keys

def get_current_session_type():
    """
    Get the current session type (X11 or Wayland).

    Returns:
        set: Set of session type keys ('wayland' if running in a Wayland session, 'x11' if running in an X11/Xlibre session)
    """
    import os
    keys = set()

    # Check for Wayland session
    wayland_display = os.environ.get("WAYLAND_DISPLAY")
    if wayland_display:
        keys.add("wayland")
    else:
        keys.add("x11")
    return keys

def are_optimizations_installed():
    """
    Check if system optimizations have been applied.

    This function checks for the presence of the autopatch state file
    which indicates that LinuxToys optimizations have been installed.

    In developer mode:
    - If OPTIMIZER=1 is set, simulate optimizations being installed (return True)
    - If OPTIMIZER=0 is set, simulate optimizations not being installed (return False)
    - If OPTIMIZER is not set, use actual file detection

    Returns:
        bool: True if optimizations are installed, False otherwise
    """
    import os

    # Check for developer mode optimizer simulation
    try:
        from .dev_mode import (
            should_simulate_optimizations_installed,
            should_simulate_optimizations_not_installed,
        )

        if should_simulate_optimizations_installed():
            return True  # Simulate optimizations installed
        if should_simulate_optimizations_not_installed():
            return False  # Simulate optimizations not installed
    except ImportError:
        # dev_mode not available, continue with normal behavior
        pass

    autopatch_state_file = os.path.expanduser("~/.local/.autopatch.state")
    return os.path.exists(autopatch_state_file)


def _script_has_optimized_only_header(script_path):
    """
    Check if a script has the optimized-only header.

    The '# optimized-only:' header marks scripts as part of the recommended
    optimizations that should be hidden when optimizations are already installed.

    Args:
        script_path (str): Path to the script file

    Returns:
        bool: True if the script has the optimized-only header, False otherwise
    """
    try:
        with open(script_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("# optimized-only:"):
                    return True
                if not line.startswith("#"):
                    break
    except Exception:
        pass
    return False


def should_show_optimization_script(script_path):
    """
    Determine if an optimization-related script should be shown based on current state.

    Hiding rules:
    - Scripts with '# optimized-only:' header are hidden when optimizations ARE installed

    The '# optimized-only:' header marks scripts as part of the recommended optimizations,
    so they are hidden when the system already has optimizations installed.

    In developer mode:
    - Without OPTIMIZER set: override optimization checks (show all scripts)
    - With OPTIMIZER=1 or OPTIMIZER=0: apply optimization simulation logic

    Args:
        script_path (str): Path to the script file

    Returns:
        bool: True if the script should be shown, False if it should be hidden
    """

    # Check for developer mode optimizer override
    try:
        from .dev_mode import should_override_optimizer_checks

        if should_override_optimizer_checks():
            return True  # Override: always show all optimization scripts
    except ImportError:
        # dev_mode not available, continue with normal behavior
        pass

    # Check for optimized-only header
    optimizations_installed = are_optimizations_installed()
    has_optimized_only = _script_has_optimized_only_header(script_path)

    # If script has optimized-only header and optimizations are installed, hide it
    if has_optimized_only and optimizations_installed:
        return False

    return True  # Show all other scripts normally


def script_uses_flatpak_in_lib(script_path):
    """
    Check if a script uses the flatpak_in_lib function.

    Args:
        script_path (str): Path to the script file

    Returns:
        bool: True if the script contains a call to flatpak_in_lib
    """
    try:
        with open(script_path, "r", encoding="utf-8") as f:
            content = f.read()
            return "flatpak_in_lib" in content
    except Exception:
        pass
    return False


def script_is_container_compatible(script_path):
    """
    Check if a script should be shown in containerized environments.

    In developer mode:
    - If CONTAINER is not set (default): override container checks (always return True)
    - If CONTAINER=1: apply normal container compatibility logic

    Scripts are considered incompatible with containers if:
    1. They use flatpak_in_lib function (automatic exclusion)
    2. They have a '# nocontainer' header (with optional system keys)

    The nocontainer header supports several formats:
    - '# nocontainer' - hide in all containers
    - '# nocontainer:' - hide in all containers (empty value)
    - '# nocontainer: debian, ubuntu' - hide only in debian/ubuntu containers
    - '# nocontainer: fedora' - hide only in fedora containers
    - '# nocontainer: invert' - show ONLY in containers (hide on host)
    - '# nocontainer: invert, debian' - show only in debian containers

    Priority rules:
    - If nocontainer header is present, it takes precedence over flatpak_in_lib
    - If nocontainer specifies keys that don't match current system, script is shown
      even if it contains flatpak_in_lib
    - If no nocontainer header, flatpak_in_lib causes automatic exclusion
    - 'invert' keyword reverses the container logic

    Args:
        script_path (str): Path to the script file

    Returns:
        bool: False if script should be hidden in containers, True otherwise
    """
    # Check for developer mode container override
    try:
        from .dev_mode import should_override_container_checks

        if should_override_container_checks():
            return True  # Override: always show scripts regardless of container compatibility
    except ImportError:
        # dev_mode not available, continue with normal behavior
        pass

    try:
        with open(script_path, "r", encoding="utf-8") as f:
            content = f.read()

            has_flatpak_in_lib = "flatpak_in_lib" in content
            nocontainer_keys = None
            has_invert = False

            # Check for nocontainer header
            for line in content.split("\n"):
                if line.startswith("# nocontainer"):
                    if ":" in line:
                        # nocontainer with specific keys
                        nocontainer_line = line[line.index(":") + 1 :].strip()
                        if nocontainer_line:
                            keys = [k.strip() for k in nocontainer_line.split(",")]
                            has_invert = "invert" in keys
                            # Remove 'invert' from the keys list to process other keys normally
                            nocontainer_keys = set([k for k in keys if k != "invert"])
                        else:
                            # Empty after colon means hide in all containers
                            nocontainer_keys = set()
                    else:
                        # Plain nocontainer means hide in all containers
                        nocontainer_keys = set()
                    break
                if not line.startswith("#"):
                    break

            # Check if we're actually in a container
            is_in_container = is_containerized()

            # If nocontainer header is present, it takes precedence
            if nocontainer_keys is not None:
                if has_invert:
                    # Invert logic: show only in containers
                    if not is_in_container:
                        return False  # Hide on host when invert is specified

                    # If we're in a container and have other keys, check compatibility
                    if len(nocontainer_keys) > 0:
                        current_compat_keys = get_system_compat_keys()
                        return bool(current_compat_keys & nocontainer_keys)
                    else:
                        # Only 'invert' specified, show in any container
                        return True
                else:
                    # Normal logic: hide in containers
                    if not is_in_container:
                        return True  # Always show on host when no invert

                    if len(nocontainer_keys) == 0:
                        # Hide in all containers
                        return False
                    else:
                        # Hide only in containers that match the specified keys
                        current_compat_keys = get_system_compat_keys()
                        return not bool(current_compat_keys & nocontainer_keys)

            # If no nocontainer header, fall back to flatpak_in_lib check
            if has_flatpak_in_lib and is_in_container:
                return False

    except Exception:
        pass
    return True  # If no restrictions, allow by default


def _script_requires_systemd_functions(script_path):
    """
    Check if a script uses systemd-specific functions that require systemd.

    Functions checked:
    - pkg_flat: Package flatpak function
    - sysd_*: Any systemd-specific function (e.g., sysd_enable, sysd_start, etc.)

    Args:
        script_path (str): Path to the script file

    Returns:
        bool: True if script uses systemd functions, False otherwise
    """
    try:
        with open(script_path, "r", encoding="utf-8") as f:
            content = f.read()

            # Check for pkg_flat function calls
            if "pkg_flat" in content:
                return True

            # Check for sysd_* function calls (e.g., sysd_enable, sysd_start, etc.)
            import re
            if re.search(r'\bsysd_\w+', content):
                return True
    except Exception:
        pass

    return False


def script_is_compatible(script_path, compat_keys):
    """
    Check if a script is compatible with the given compatibility keys.

    In developer mode without COMPAT override, all scripts are considered compatible.

    Args:
        script_path (str): Path to the script file
        compat_keys (set): Set of compatibility keys for the current system

    Returns:
        bool: True if script is compatible, False otherwise
    """
    # Check if developer mode override is active
    try:
        from .dev_mode import get_dev_compat_override, is_dev_mode_enabled

        if is_dev_mode_enabled() and not get_dev_compat_override():
            # Developer mode without specific system simulation - show all scripts
            return True
    except ImportError:
        # dev_mode not available, continue with normal behavior
        pass

    os_compatible = True
    gpu_compatible = True  # Default for unset GPU header
    desktop_compatible = True  # Default for unset desktop header
    systemd_compatible = True  # Default for unset systemd header
    wayland_compatible = True  # Default for unset wayland header (presume neutrality)
    cpu_compatible = True # Default for unset cpu header
    has_explicit_systemd_header = False  # Track if systemd header was explicitly set

    try:
        with open(script_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("# compat:"):
                    compat_line = line[len("# compat:") :].strip()
                    key_strings = [k.strip() for k in compat_line.split(",")]
                    include_keys = set()
                    exclude_keys = set()

                    # Parse keys into include (whitelist) and exclude (blacklist)
                    for key_str in key_strings:
                        if key_str.startswith("!"):
                            exclude_keys.add(key_str[1:])
                        else:
                            include_keys.add(key_str)

                    # Check whitelist (include keys) - if specified, script must match at least one
                    if include_keys:
                        os_compatible = bool(compat_keys & include_keys)
                    else:
                        # No whitelist specified, default to True
                        os_compatible = True

                    # Check blacklist (exclude keys) - if specified, script must not match any
                    if exclude_keys:
                        os_compatible = os_compatible and not bool(
                            compat_keys & exclude_keys
                        )
                elif line.startswith("# gpu:"):
                    gpu_value = line[len("# gpu:") :].strip()
                    gpu_values = [v.strip() for v in gpu_value.split(",") if v.strip()]
                    gpu_script_keys = set()
                    for v in gpu_values:
                        v_lower = v.lower()
                        if v_lower == "amd":
                            gpu_script_keys.add("gpu-amd")
                        elif v_lower == "intel":
                            gpu_script_keys.add("gpu-intel")
                        elif v_lower == "nvidia":
                            gpu_script_keys.add("gpu-nvidia")
                        else:
                            # Unknown value, treat as general GPU
                            gpu_script_keys.add("gpu")
                    if gpu_script_keys:
                        gpu_compatible = bool(compat_keys & gpu_script_keys)
                    else:
                        # Empty header, treat as general GPU
                        gpu_compatible = "gpu" in compat_keys
                elif line.startswith("# desktop:"):
                    desktop_value = line[len("# desktop:") :].strip()
                    desktop_values = [
                        v.strip() for v in desktop_value.split(",") if v.strip()
                    ]
                    desktop_script_keys = set()
                    for v in desktop_values:
                        if v.lower() == "gnome":
                            desktop_script_keys.add("desktop-gnome")
                        elif v.lower() == "plasma":
                            desktop_script_keys.add("desktop-plasma")
                        elif v.lower() == "other":
                            desktop_script_keys.add("desktop-other")
                        else:
                            # Unknown value, treat as general desktop
                            desktop_script_keys.add("desktop")
                    if desktop_script_keys:
                        desktop_compatible = bool(compat_keys & desktop_script_keys)
                    else:
                        # Empty header, treat as general desktop
                        desktop_compatible = "desktop" in compat_keys
                elif line.startswith("# systemd:"):
                    has_explicit_systemd_header = True
                    # systemd header with optional value (e.g., "yes" or "no" - for flexibility)
                    systemd_value = line[len("# systemd:") :].strip().lower()
                    # If header exists and is explicitly "no", script requires non-systemd
                    if systemd_value == "no":
                        systemd_compatible = "systemd" not in compat_keys
                    else:
                        # Default: "yes" or empty means script requires systemd
                        systemd_compatible = "systemd" in compat_keys
                elif line.startswith("# wayland:"):
                    wayland_value = line[len("# wayland:") :].strip().lower()
                    if wayland_value in ["yes", "true"]:
                        wayland_compatible = "wayland" in compat_keys
                    elif wayland_value in ["no", "false"]:
                        wayland_compatible = "x11" in compat_keys
                elif line.startswith("# cpu:"):
                    cpu_val = line[len("# cpu:") :].strip()
                    cpu_vals = [v.strip() for v in cpu_val.split(",") if v.strip()]
                    cpu_script_keys = set()
                    for v in cpu_vals:
                        v_lower = v.lower()
                        if v_lower == "amd":
                            cpu_script_keys.add("cpu-amd")
                        elif v_lower == "intel":
                            cpu_script_keys.add("cpu-intel")
                        else:
                            cpu_script_keys.add("cpu")
                    if cpu_script_keys:
                        cpu_compatible = bool(compat_keys & cpu_script_keys)
                    else:
                        # Empty header, treat as general GPU
                        cpu_compatible = "cpu" in compat_keys
                if not line.startswith("#"):
                    break
    except Exception:
        pass

    # If no explicit systemd header was found, check for implicit systemd requirements
    # via function calls (pkg_flat or sysd_*)
    if not has_explicit_systemd_header and _script_requires_systemd_functions(script_path):
        systemd_compatible = "systemd" in compat_keys

    # If no explicit wayland header, presume neutrality (script works on both X11 and Wayland)
    # wayland_compatible remains True by default

    return os_compatible and gpu_compatible and desktop_compatible and systemd_compatible and wayland_compatible and cpu_compatible


def script_is_localized(script_path, current_locale):
    """
    Check if a script should be shown for the current locale.
    Returns True if:
    - No 'localize' header is present (show by default)
    - 'localize' header contains the current locale
    """
    try:
        with open(script_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("# localize:"):
                    localize_line = line[len("# localize:") :].strip()
                    localize_keys = set(
                        [k.strip().lower() for k in localize_line.split(",")]
                    )
                    return current_locale.lower() in localize_keys
                if not line.startswith("#"):
                    break
    except Exception:
        pass
    return True  # If no localize header, show by default

def get_revert_capability(script_path, compat_keys=None):
    """
    Get the revert capability for a script based on the '# revert:' header.
    
    Possible return values:
    - 'yes': Reversion both automatic after error and manual through uninstall button
    - 'no': Reversion unavailable both automatically and manually
    - 'internal': Automatic reversion available, but manual uninstallation requires running script again
    - 'conditional': List of compat keys for which reversion is available (whitelist/blacklist)
    - None: No revert header found, defaults to 'yes'
    
    The header format supports:
    - # revert: yes (or omitted, defaults to 'yes')
    - # revert: no
    - # revert: internal
    - # revert: ubuntu, fedora (whitelist - yes for these keys only)
    - # revert: !ubuntu, !fedora (blacklist - yes for all except these keys)
    
    Args:
        script_path (str): Path to the script file
        compat_keys (set): Set of compatibility keys for the current system (optional)
    
    Returns:
        str or dict: Revert capability string ('yes', 'no', 'internal') or dict with conditional info
    """
    if compat_keys is None:
        compat_keys = get_system_compat_keys()
    
    try:
        with open(script_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("# revert:"):
                    revert_line = line[len("# revert:") :].strip().lower()
                    
                    # Handle simple cases
                    if revert_line == "yes" or revert_line == "":
                        return "yes"
                    elif revert_line == "no":
                        return "no"
                    elif revert_line == "internal":
                        return "internal"
                    else:
                        # Parse as compatibility keys (whitelist/blacklist)
                        key_strings = [k.strip() for k in revert_line.split(",")]
                        include_keys = set()
                        exclude_keys = set()
                        
                        for key_str in key_strings:
                            if key_str.startswith("!"):
                                exclude_keys.add(key_str[1:])
                            else:
                                include_keys.add(key_str)
                        
                        return {
                            "type": "conditional",
                            "include_keys": include_keys,
                            "exclude_keys": exclude_keys,
                            "compat_keys": compat_keys,
                        }
                
                if not line.startswith("#"):
                    break
    except Exception:
        pass
    
    return "yes"  # Default to 'yes' if no header found


def should_enable_manual_revert(script_path, compat_keys=None):
    """
    Determine if manual uninstallation (remove button) should be available for a script.
    
    Returns True if:
    - revert header is 'yes' or not set (default)
    - revert header is conditional and script matches the compat conditions
    
    Returns False if:
    - revert header is 'no'
    - revert header is 'internal'
    - revert header is conditional and system doesn't match the conditions
    
    Args:
        script_path (str): Path to the script file
        compat_keys (set): Set of compatibility keys for the current system (optional)
    
    Returns:
        bool: True if manual revert should be enabled, False otherwise
    """
    if compat_keys is None:
        compat_keys = get_system_compat_keys()
    
    revert_capability = get_revert_capability(script_path, compat_keys)
    
    if revert_capability == "yes":
        return True
    elif revert_capability == "no":
        return False
    elif revert_capability == "internal":
        return False
    elif isinstance(revert_capability, dict) and revert_capability.get("type") == "conditional":
        # Check if system matches the compat conditions
        include_keys = revert_capability.get("include_keys", set())
        exclude_keys = revert_capability.get("exclude_keys", set())
        script_compat_keys = revert_capability.get("compat_keys", compat_keys)
        
        # If include keys specified (whitelist)
        if include_keys:
            matches_include = bool(script_compat_keys & include_keys)
        else:
            # No whitelist specified
            matches_include = True
        
        # If exclude keys specified (blacklist)
        if exclude_keys:
            matches_exclude = bool(script_compat_keys & exclude_keys)
        else:
            # No blacklist specified
            matches_exclude = False
        
        return matches_include and not matches_exclude
    
    return True  # Default to True
