"""
Registry-based revert helper for undoing LinuxToys script installations.

Uses the execution registry to track and reverse operations performed during script execution.
Each operation is reversed, with file restorations from .bak files and package removals executed.
"""

import os
import tempfile
import subprocess


def _run_ok(cmd):
    """Execute a command and return True if successful."""
    try:
        return subprocess.run(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        ).returncode == 0
    except Exception:
        return False


def _detect_package_manager():
    """Detect which package manager is available on the system."""
    if _run_ok(["bash", "-lc", "command -v rpm-ostree >/dev/null 2>&1"]):
        return "rpm-ostree"
    if _run_ok(["bash", "-lc", "command -v apt >/dev/null 2>&1"]):
        return "apt"
    if _run_ok(["bash", "-lc", "command -v dnf >/dev/null 2>&1"]):
        return "dnf"
    if _run_ok(["bash", "-lc", "command -v pacman >/dev/null 2>&1"]):
        return "pacman"
    if _run_ok(["bash", "-lc", "command -v zypper >/dev/null 2>&1"]):
        return "zypper"
    if _run_ok(["bash", "-lc", "command -v eopkg >/dev/null 2>&1"]):
        return "eopkg"
    return None


def _load_from_transmap(transmap_path):
    """
    Load operations from a transmap file created during script execution.
    
    Returns a list of operation strings in the order they appear in the file.
    Returns empty list if file doesn't exist or cannot be read.
    """
    if not os.path.exists(transmap_path):
        return []
    
    try:
        with open(transmap_path, "r") as f:
            content = f.read()
    except Exception:
        return []
    
    operations = []
    
    # Parse operation lines (format: "operation_type operand1 operand2 ...")
    for line in content.split("\n"):
        line = line.strip()
        if line and not line.startswith("#"):  # Skip empty lines and comments
            operations.append(line)
    
    return operations


def _load_last_execution(script_name):
    """
    Load the last execution record from the registry for the given script.
    
    Returns a list of operations (operation_type, operands) or empty list if not found.
    Operations are in the order they appear in registry (original execution order).
    """
    registry_file = os.path.expanduser("~/.cache/linuxtoys/registry")
    
    if not os.path.exists(registry_file):
        return []
    
    try:
        with open(registry_file, "r") as f:
            content = f.read()
    except Exception:
        return []
    
    # Split by registry entries (format: [timestamp] Script: name\nChanges:\n  - operation)
    entries = content.split("---\n")
    entries.reverse()  # Start from most recent
    
    for entry in entries:
        entry = entry.strip()
        if not entry:
            continue
        
        lines = entry.split("\n")
        if not lines:
            continue
        
        # First line should have the script name
        first_line = lines[0] if lines else ""
        if f"Script: {script_name}" not in first_line:
            continue
        
        # Found the matching script execution
        operations = []
        
        # Parse operation lines (those starting with "  - ")
        for line in lines[1:]:
            line = line.strip()
            if line.startswith("- "):
                # Remove "- " prefix and parse operation
                op_line = line[2:].strip()
                if op_line and op_line != "Changes:" and op_line != "Changes: (none)":
                    operations.append(op_line)
        
        return operations
    
    return []


def _get_executed_script_names():
    """
    Return a set of script names that have non-empty execution records.

    This is a faster alternative to calling _load_last_execution for every
    script when only the presence of a record is needed (e.g. caching the
    removable state of many scripts at once).
    """
    registry_file = os.path.expanduser("~/.cache/linuxtoys/registry")
    executed = set()

    if not os.path.exists(registry_file):
        return executed

    try:
        with open(registry_file, "r") as f:
            content = f.read()
    except Exception:
        return executed

    entries = content.split("---\n")

    for entry in entries:
        entry = entry.strip()
        if not entry:
            continue

        lines = entry.split("\n")
        if not lines:
            continue

        first_line = lines[0]
        if "Script: " not in first_line:
            continue

        script_name = first_line.split("Script: ", 1)[1].strip()
        if not script_name:
            continue

        # Only count entries that actually recorded changes
        has_operations = False
        for line in lines[1:]:
            line = line.strip()
            if line.startswith("- "):
                op_line = line[2:].strip()
                if op_line and op_line not in ("Changes:", "Changes: (none)"):
                    has_operations = True
                    break

        if has_operations:
            executed.add(script_name)

    return executed


def _parse_operation(op_line):
    """
    Parse an operation line from the transmap.
    
    Returns a tuple of (operation_type, operands_list)
    E.g., "pkg curl git vim" -> ("pkg install", ["curl", "git", "vim"])
          "pkg rm curl" -> ("pkg rm", ["curl"])
          "pkg file /path/to/pkg.deb" -> ("pkg file", ["/path/to/pkg.deb"])
          "edited /etc/config" -> ("edited", ["/etc/config"])
          "sysd enabled ssh" -> ("sysd", ["enabled", "ssh"])
          "flatpak app1 app2" -> ("flatpak", ["app1", "app2"])
          "chsh /bin/zsh" -> ("chsh", ["/bin/zsh"])
          "WARN: message text" -> ("warn", ["message", "text", ...])
    """
    parts = op_line.split()
    if not parts:
        return None, []
    
    op_type = parts[0]
    
    # Strip trailing colon from operation type if present (e.g., "WARN:" -> "warn")
    if op_type.endswith(':'):
        op_type = op_type[:-1].lower()
    else:
        op_type = op_type.lower() if op_type.lower() in ("warn",) else op_type
    
    if len(parts) > 1:
        # For operations with multiple parts (e.g., "sysd enabled service")
        if op_type == "sysd":
            # sysd operations have format: "sysd action service"
            if len(parts) >= 3:
                return op_type, [parts[1], parts[2]]  # ["enabled", "ssh"]
            else:
                return op_type, parts[1:] if len(parts) > 1 else []
        elif op_type == "pkg":
            # pkg operations have different formats:
            # "pkg rm package" -> distinguish removal
            # "pkg file /path" -> distinguish from file
            # "pkg package1 package2" -> regular installation
            if len(parts) >= 2 and parts[1] == "rm":
                # Removal: "pkg rm curl" or "pkg rm curl git"
                return "pkg rm", parts[2:]
            elif len(parts) >= 2 and parts[1] == "file":
                # From file: "pkg file /path/to/file"
                return "pkg file", parts[2:]
            else:
                # Installation: "pkg curl git vim"
                return "pkg install", parts[1:]
        elif op_type == "flatpak":
            # flatpak can have multiple operands (e.g., "flatpak app1 app2")
            return op_type, parts[1:]
        elif op_type == "appimage":
            # appimage can have multiple operands (e.g., "appimage file1.appimage file2.appimage")
            return op_type, parts[1:]
        elif op_type == "npm":
            # npm operations have format: "npm package" or "npm pkg1 pkg2" (multiple packages)
            return op_type, parts[1:]
        elif op_type == "bun":
            # bun operations have format: "bun package" or "bun pkg1 pkg2" (multiple packages)
            return op_type, parts[1:]
        elif op_type == "distrobox":
            # distrobox operations have format: "distrobox container_name"
            return op_type, parts[1:]
        elif op_type == "rclone":
            # rclone operations have format: "rclone mounted /source /destination"
            if len(parts) >= 2 and parts[1] == "mounted":
                return "rclone mounted", parts[2:]
            return op_type, parts[1:]
        elif op_type == "chsh":
            # Shell change: "chsh /bin/zsh"
            return op_type, parts[1:]
        elif op_type == "swapfile":
            # Swapfile operations: "swapfile btrfs /path/to/swapfile" or "swapfile regular /path/to/swapfile"
            return op_type, parts[1:]
        elif op_type == "warn":
            # Warning: "WARN: message text" -> keep all parts as operands
            return op_type, parts[1:]
        else:
            # Most operations: "type operand" (e.g., "edited /etc/config")
            return op_type, [parts[1]]
    
    return op_type, []


def _reverse_package_install(packages, package_manager):
    """Reverse a package installation by removing it(s).
    
    Args:
        packages: list of package names or single package name string
        package_manager: detected package manager
    
    Returns:
        list of shell commands to reverse the package installation
    """
    if not package_manager:
        return []
    
    # Normalize to list
    if isinstance(packages, str):
        packages = [packages]
    
    if not packages:
        return []
    
    # Use pkg_remove library function to handle distro-specific removal
    pkg_args = " ".join(packages)
    return [f"pkg_remove {pkg_args}"]


def _reverse_package_removal(packages, package_manager):
    """Reverse a package removal by reinstalling it(s).
    
    Args:
        packages: list of package names or single package name string
        package_manager: detected package manager
    
    Returns:
        list of shell commands to reverse the package removal
    """
    if not package_manager:
        return []
    
    # Normalize to list
    if isinstance(packages, str):
        packages = [packages]
    
    if not packages:
        return []
    
    # Use pkg_install library function to handle distro-specific reinstallation
    pkg_args = " ".join(packages)
    return [f"pkg_install {pkg_args}"]


def _reverse_package_fromfile(file_paths):
    """Reverse a package-from-file installation by removing it(s).
    
    Attempts to extract package name from file path and remove it.
    For .deb files, extracts name before first underscore.
    For .pkg.tar.zst files, similar approach.
    For .flatpak bundles, extracts app ID using flatpak info.
    
    Args:
        file_paths: list of file paths or single file path string
    
    Returns:
        list of shell commands to reverse the package installation
    """
    # Normalize to list
    if isinstance(file_paths, str):
        file_paths = [file_paths]
    
    if not file_paths:
        return []
    
    packages_to_remove = []
    flatpak_app_ids = []
    
    for file_path in file_paths:
        basename = os.path.basename(file_path)
        
        # Handle flatpak bundles specially
        if basename.endswith('.flatpak'):
            # Try to extract app ID from the flatpak bundle using flatpak info
            try:
                result = subprocess.run(
                    ["flatpak", "info", file_path],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    text=True,
                    check=False,
                )
                if result.returncode == 0:
                    # Parse output to find ID= line
                    for line in result.stdout.split('\n'):
                        if line.startswith('ID='):
                            app_id = line.split('=', 1)[1].strip()
                            flatpak_app_ids.append(app_id)
                            break
            except Exception:
                pass
            continue
        
        # Extract package name from filename for other package types
        if basename.endswith('.deb'):
            # For deb files: package_1.0-1_amd64.deb -> package
            pkg_name = basename.split('_')[0]
            packages_to_remove.append(pkg_name)
        elif basename.endswith('.pkg.tar.zst') or basename.endswith('.pkg.tar.xz'):
            # For arch packages: package-1.0-1-x86_64.pkg.tar.zst -> package
            pkg_name = basename.split('-')[0]
            packages_to_remove.append(pkg_name)
        elif basename.endswith('.rpm'):
            # For rpm files: package-1.0-1.fc35.x86_64.rpm -> package
            pkg_name = basename.replace('.rpm', '').rsplit('-', 2)[0]
            packages_to_remove.append(pkg_name)
    
    # Build reversal commands
    reversal_commands = []
    
    if packages_to_remove:
        # Use pkg_remove library function to safely remove the packages
        pkg_args = " ".join(packages_to_remove)
        reversal_commands.append(f"pkg_remove {pkg_args}")
    
    if flatpak_app_ids:
        # Use flatpak uninstall for extracted app IDs
        for app_id in flatpak_app_ids:
            cmd = (
                f"flatpak uninstall --user --noninteractive {app_id} 2>/dev/null || true ; "
                f"sudo flatpak uninstall --system --noninteractive {app_id} 2>/dev/null || true"
            )
            reversal_commands.append(cmd)
    
    return reversal_commands


def _reverse_file_deletion(file_path):
    """Reverse file deletion by removing the created file.
    
    Attempts removal without sudo first. If permission is denied,
    calls sudo_rq and retries with root access.
    """
    # Try without sudo first; if permission denied, request sudo and retry
    return (
        f"rm -rf {file_path} 2>/dev/null || "
        f"{{ sudo_rq && sudo rm -rf {file_path} 2>/dev/null; }} || true"
    )


def _reverse_file_restoration(file_path):
    """Reverse a file or directory change by restoring from .bak file/directory.
    
    Attempts restoration without sudo first. If permission is denied,
    calls sudo_rq and retries with root access.
    """
    backup_path = f"{file_path}.bak"
    
    # Check if backup exists
    if not os.path.exists(backup_path):
        return None
    
    # Try without sudo first; if permission denied, request sudo and retry
    # Use proper quoting to handle paths with spaces and special characters
    return (
        f"{{ rm -rf {file_path} && mv {backup_path} {file_path}; }} 2>/dev/null || "
        f"{{ sudo_rq && sudo bash -c 'rm -rf \"{file_path}\" && mv \"{backup_path}\" \"{file_path}\"'; }} || true"
    )


def _reverse_flatpak_removal(app_ids):
    """Reverse flatpak installation(s) by removing it/them.
    
    Args:
        app_ids: list of app IDs or single app ID string
    
    Returns:
        list of shell commands to reverse the flatpak installation
    """
    # Normalize to list
    if isinstance(app_ids, str):
        app_ids = [app_ids]
    
    if not app_ids:
        return []
    
    commands = []
    for app_id in app_ids:
        # Remove from both user and system scopes
        cmd = (
            f"flatpak uninstall --user --noninteractive {app_id} 2>/dev/null || true ; "
            f"sudo flatpak uninstall --system --noninteractive {app_id} 2>/dev/null || true"
        )
        commands.append(cmd)
    
    return commands


def _reverse_appimage_removal(appimage_files):
    """Reverse appimage installation(s) by removing it/them.
    
    Args:
        appimage_files: list of appimage filenames or single filename string
    
    Returns:
        list of shell commands to reverse the appimage installation
    """
    # Normalize to list
    if isinstance(appimage_files, str):
        appimage_files = [appimage_files]
    
    if not appimage_files:
        return []
    
    # Use pkg_appimage_rm library function to handle appimage removal
    appimage_args = " ".join(appimage_files)
    return [f"pkg_appimage_rm {appimage_args}"]


def _reverse_npm_installation(packages):
    """Reverse npm package installation(s) by removing them globally.
    
    Args:
        packages: list of package names or single package name string
    
    Returns:
        list of shell commands to reverse the npm package installation
    """
    # Normalize to list
    if isinstance(packages, str):
        packages = [packages]
    
    if not packages:
        return []
    
    commands = []
    for package in packages:
        # Uninstall globally using npm uninstall -g
        cmd = f"npm uninstall -g {package} 2>/dev/null || true"
        commands.append(cmd)
    
    return commands


def _reverse_bun_installation(packages):
    """Reverse bun package installation(s) by removing them globally.
    
    Args:
        packages: list of package names or single package name string
    
    Returns:
        list of shell commands to reverse the bun package installation
    """
    # Normalize to list
    if isinstance(packages, str):
        packages = [packages]
    
    if not packages:
        return []
    
    commands = []
    for package in packages:
        # Uninstall globally using bun remove -g
        cmd = f"bun remove -g {package} 2>/dev/null || true"
        commands.append(cmd)
    
    return commands


def _reverse_distrobox_creation(container_names):
    """Reverse distrobox container creation(s) by removing it/them.
    
    Args:
        container_names: list of container names or single container name string
    
    Returns:
        list of shell commands to reverse the distrobox creation
    """
    # Normalize to list
    if isinstance(container_names, str):
        container_names = [container_names]
    
    if not container_names:
        return []
    
    commands = []
    for container_name in container_names:
        # Remove the distrobox container
        cmd = f"distrobox rm --force {container_name} 2>/dev/null || true"
        commands.append(cmd)
    
    return commands


def _reverse_rclone_mount(mount_paths):
    """Reverse rclone mountpoint creation(s) by unmounting it/them.
    
    Args:
        mount_paths: list of mount destination paths or single path string
    
    Returns:
        list of shell commands to reverse the rclone mounting
    """
    # For rclone mounted operations, the operands are [source, destination]
    # We only need to unmount the destination
    # Normalize to list (could be single path or paired source/dest)
    if isinstance(mount_paths, str):
        mount_paths = [mount_paths]
    
    if not mount_paths:
        return []
    
    commands = []
    # If we have an even number of paths, they're pairs (source, dest)
    # If odd, assume the last one is the destination
    if len(mount_paths) % 2 == 0:
        # Even: process pairs, unmount every second element (destination)
        for i in range(1, len(mount_paths), 2):
            destination = mount_paths[i]
            # Try fusermount first (modern FUSE), then umount fallback
            cmd = f"fusermount -u {destination} 2>/dev/null || sudo umount {destination} 2>/dev/null || true"
            commands.append(cmd)
    else:
        # Odd: assume single destination or unpaired paths
        for path in mount_paths:
            cmd = f"fusermount -u {path} 2>/dev/null || sudo umount {path} 2>/dev/null || true"
            commands.append(cmd)
    
    return commands


def _reverse_systemd_operation(service, action):
    """Reverse systemd operations."""
    reversals = {
        "enabled": "sudo systemctl disable",
        "disabled": "sudo systemctl enable",
        "started": "sudo systemctl stop",
        "stopped": "sudo systemctl start",
    }
    
    if action not in reversals:
        return None
    
    return f"{reversals[action]} {service}"


def _reverse_systemd_usermode_operation(service, action):
    """Reverse user-level systemd operations (without sudo).
    
    User-level systemd operations are run by the user for their own services,
    so they don't need sudo and use --user flag instead.
    """
    reversals = {
        "enabled": "systemctl --user disable",
        "disabled": "systemctl --user enable",
        "started": "systemctl --user stop",
        "stopped": "systemctl --user start",
    }
    
    if action not in reversals:
        return None
    
    return f"{reversals[action]} {service}"


def _reverse_bootloader_update():
    """
    Reverse a bootloader update by triggering another bootloader update.
    
    Bootloader updates are idempotent, so re-running the update ensures
    consistency and reverses any partial or corrupted state.
    Uses the bootloader_upd function from linuxtoys.lib for proper distro handling.
    """
    return "bootloader_upd"


def _reverse_initramfs_update():
    """
    Reverse an initramfs update by triggering another initramfs update.
    
    Initramfs updates are idempotent, so re-running the update ensures
    consistency and reverses any partial or corrupted state.
    Uses the initramfs_upd function from linuxtoys.lib for proper distro handling.
    """
    return "initramfs_upd"


def _reverse_shell_change(shell_path):
    """Reverse a shell change by reverting to bash.
    
    Args:
        shell_path: the shell that was changed to (ignored, always revert to bash)
    
    Returns:
        list containing a single shell_change command to revert to bash
    """
    # Always revert to /bin/bash, the standard default shell
    return ["shell_change /bin/bash $USER"]


def _reverse_kargs_update(karg):
    """
    Reverse a kernel argument update by deleting the appended karg.
    
    Uses rpm-ostree kargs --delete to remove the previously appended kernel argument.
    """
    if not karg:
        return None
    
    return f"sudo rpm-ostree kargs --delete=\"{karg}\" || true"


def _reverse_grubbyargs_update(karg):
    """
    Reverse a grubby kernel argument update by removing the appended karg.
    
    Uses grubby --remove-args to remove the previously appended kernel argument.
    """
    if not karg:
        return None
    
    return f"sudo grubby --remove-args=\"{karg}\" --update-kernel ALL || true"


def _reverse_swapfile_creation(swapfile_type, swapfile_path):
    """
    Reverse swapfile creation by disabling and removing the swapfile.
    
    Handles both btrfs and regular swapfile types by:
    1. Disabling the swapfile with swapoff
    2. Removing the swapfile entry from /etc/fstab
    3. Deleting the swapfile
    4. For btrfs swapfiles, updating initramfs to ensure proper kernel configuration
    
    Args:
        swapfile_type: "btrfs" or "regular" indicating the swapfile type
        swapfile_path: path to the swapfile to remove
    
    Returns:
        list of shell commands to reverse the swapfile creation
    """
    if not swapfile_path:
        return []
    
    commands = []
    
    # Disable the swapfile
    commands.append(f"sudo swapoff {swapfile_path} 2>/dev/null || true")
    
    # Remove the swapfile entry from fstab (escape special characters in path)
    escaped_path = swapfile_path.replace("/", "\\/")
    commands.append(f'sudo sed -i "\\|{escaped_path}|d" /etc/fstab || true')
    
    # Remove the swapfile itself
    commands.append(f"sudo rm -f {swapfile_path} || true")
    
    # For btrfs swapfiles, update initramfs since kernel parameters may have been set
    if swapfile_type and swapfile_type.lower() == "btrfs":
        commands.append("initramfs_upd")
    
    return commands


def _reverse_operation(op_line, package_manager):
    """
    Generate shell command(s) to reverse a single operation.
    
    Returns a list of command strings or empty list if unable to reverse.
    """
    op_type, operands = _parse_operation(op_line)
    
    # WARN entries are informational only - no reversal action needed
    if op_type == "warn":
        return []
    
    elif op_type == "pkg install" and operands:
        # Reverse package installation by removing
        return _reverse_package_install(operands, package_manager)
    
    elif op_type == "pkg rm" and operands:
        # Reverse package removal by reinstalling
        return _reverse_package_removal(operands, package_manager)
    
    elif op_type == "pkg file" and operands:
        # Reverse package-from-file installation by removing
        return _reverse_package_fromfile(operands)
    
    elif op_type == "flatpak" and operands:
        return _reverse_flatpak_removal(operands)
    
    elif op_type == "appimage" and operands:
        return _reverse_appimage_removal(operands)
    
    elif op_type == "npm" and operands:
        return _reverse_npm_installation(operands)
    
    elif op_type == "bun" and operands:
        return _reverse_bun_installation(operands)
    
    elif op_type == "distrobox" and operands:
        # Reverse distrobox container creation by removing
        return _reverse_distrobox_creation(operands)
    
    elif op_type == "rclone mounted" and operands:
        # Reverse rclone mountpoint creation by unmounting
        return _reverse_rclone_mount(operands)
    
    elif op_type == "chsh" and operands:
        # Reverse shell change by reverting to bash
        return _reverse_shell_change(operands[0])
    
    elif op_type == "swapfile" and len(operands) >= 2:
        # Reverse swapfile creation: format is "swapfile type path"
        # operands[0] = type ("btrfs" or "regular")
        # operands[1] = path to the swapfile
        return _reverse_swapfile_creation(operands[0], operands[1])
    
    elif op_type == "created" and operands:
        # Reverse created files by deleting them
        return [_reverse_file_deletion(operands[0])]
    
    elif op_type in ("edited", "removed") and operands:
        # Reverse edited/removed files by restoring from .bak backup
        # File operations typically have one file per operation
        cmd = _reverse_file_restoration(operands[0])
        return [cmd] if cmd else []
    
    elif op_type == "sysd" and len(operands) >= 2:
        # Check if this is a usermode operation
        if operands[0] == "usermode" and len(operands) >= 3:
            # Format: "sysd usermode action service"
            action, service = operands[1], operands[2]
            cmd = _reverse_systemd_usermode_operation(service, action)
            return [cmd] if cmd else []
        else:
            # Format: "sysd action service" (system-level)
            action, service = operands[0], operands[1]
            cmd = _reverse_systemd_operation(service, action)
            return [cmd] if cmd else []
    
    elif op_type == "updated" and "bootloader" in op_line:
        # Bootloader updates need to be re-run to ensure consistency
        cmd = _reverse_bootloader_update()
        return [cmd] if cmd else []
    
    elif op_type == "updated" and "initramfs" in op_line:
        # Initramfs updates need to be re-run to ensure consistency
        cmd = _reverse_initramfs_update()
        return [cmd] if cmd else []
    
    elif op_type == "updated" and "kargs" in op_line:
        # Check if this is grubby kargs or rpm-ostree kargs
        # grubby kargs format: "updated grubby kargs kernel-argument"
        # rpm-ostree kargs format: "updated kargs kernel-argument"
        
        if "grubby" in op_line:
            # Extract the kargs value from "updated grubby kargs kernel-argument"
            parts = op_line.split(None, 3)  # ["updated", "grubby", "kargs", "kernel-argument"]
            if len(parts) >= 4:
                karg = parts[3]
                cmd = _reverse_grubbyargs_update(karg)
                return [cmd] if cmd else []
        else:
            # Extract the kargs value from "updated kargs kernel-argument"
            parts = op_line.split(None, 2)  # ["updated", "kargs", "kernel-argument"]
            if len(parts) >= 3:
                karg = parts[2]
                cmd = _reverse_kargs_update(karg)
                return [cmd] if cmd else []
        return []
    
    return []


def build_uninstall_script_entry(script_info, translations=None):
    """
    Build a temporary uninstall script for a given LinuxToys script.
    
    Reads the last execution record from the registry and generates
    reverse operations to undo the changes.
    
    Returns a script_info-like dict or None when no removable components were found.
    """
    script_path = script_info.get("path")
    if not script_path or not os.path.isfile(script_path):
        return None
    
    script_name = script_info.get("name", "unknown")
    
    # Load the last execution from registry
    operations = _load_last_execution(script_name)
    
    if not operations:
        # No registry entry found for this script
        return None
    
    package_manager = _detect_package_manager()
    
    # Generate reverse commands (in reverse order)
    reverse_commands = []
    for op_line in reversed(operations):
        cmds = _reverse_operation(op_line, package_manager)
        if cmds:
            reverse_commands.extend(cmds)
    
    if not reverse_commands:
        # No reversible operations found
        return None
    
    script_dir = os.environ.get('SCRIPT_DIR', os.path.dirname(os.path.dirname(__file__)))
    
    lines = [
        "#!/bin/bash",
        "set -eo pipefail",
        f'SCRIPT_DIR="{script_dir}"',
        'source "$SCRIPT_DIR/libs/linuxtoys.lib"',
        'source "$SCRIPT_DIR/libs/helpers.lib"',
    ]
    
    # Check if we need sudo
    needs_sudo = any(
        cmd.strip().startswith("sudo ") for cmd in reverse_commands
    )
    
    if needs_sudo:
        lines.append("")
        lines.append("# Request sudo authorization")
        lines.append("sudo_rq")
    
    lines.append("")
    lines.append("# Reverse operations (in reverse order, most recent first)")
    lines.extend(reverse_commands)
    lines.append("")
    lines.append("")
    lines.append("# Remove script from action registry upon successful completion")
    lines.append("python3 -c '")
    lines.append("import os, re")
    lines.append("reg = os.path.expanduser(\"~/.cache/linuxtoys/registry\")")
    lines.append("if os.path.exists(reg):")
    lines.append("    with open(reg, \"r\") as f: content = f.read()")
    lines.append("    # Regex to capture individual blocks starting from a timestamp to the next timestamp or EOF")
    lines.append("    pattern = r\"(\\[\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}[^\\]]*\\] Script: [^\\n]+\\n(?:(?!\\n\\[\\d{4}).)*)\"")
    lines.append("    blocks = re.findall(pattern, content, re.DOTALL)")
    lines.append("    filtered_blocks = []")
    lines.append("    for block in blocks:")
    lines.append("        # Extract the header line to check the script name accurately")
    # Escape quotes inside the dynamically generated script name
    escaped_script_name = script_name.replace("'", "'\"'\"'")
    lines.append(f"        if \"Script: {escaped_script_name}\" in block.split(\"\\n\")[0]: continue")
    lines.append("        filtered_blocks.append(block)")
    lines.append("    if filtered_blocks:")
    lines.append("        # Clean separators layout back down to file")
    lines.append("        cleaned_content = \"\"")
    lines.append("        for b in filtered_blocks:")
    lines.append("            b_clean = b.strip()")
    lines.append("            if not b_clean.endswith(\"---\"): b_clean += \"\\n---\"")
    lines.append("            cleaned_content += b_clean + \"\\n\\n\"")
    lines.append("        with open(reg, \"w\") as f: f.write(cleaned_content)")
    lines.append("    else:")
    lines.append("        if os.path.exists(reg): os.remove(reg)")
    lines.append("'")
    lines.append("")
    lines.append('echo "Removal completed."')
    
    # Write temporary script
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", prefix="linuxtoys-uninstall-", suffix=".sh", delete=False
        ) as temp_script:
            temp_script.write("\n".join(lines) + "\n")
            temp_path = temp_script.name
    except Exception:
        return None
    
    os.chmod(temp_path, 0o700)
    
    # Prepare return entry
    script_name_display = script_info.get("name", "Script")
    remove_name = (
        translations.get("remove_action_name", "Remove {name}")
        if translations
        else "Remove {name}"
    ).format(name=script_name_display)
    
    return {
        "icon": script_info.get("icon", "application-x-executable"),
        "name": remove_name,
        "description": translations.get(
            "remove_action_desc",
            "Automatically removes components installed by this script using the registry.",
        )
        if translations
        else "Automatically removes components installed by this script using the registry.",
        "repo": script_info.get("repo", ""),
        "path": temp_path,
        "is_script": True,
        "cleanup_path": temp_path,
    }


def build_auto_revert_script_entry(script_info, transmap_path, translations=None):
    """
    Build a temporary auto-revert script for a script that exited with an error.
    
    Reads the transmap file created during script execution and generates
    reverse operations to undo the changes made before the error occurred.
    
    Returns a script_info-like dict or None when no reversible operations were found.
    """
    if not os.path.exists(transmap_path):
        return None
    
    # Load operations from the transmap file
    operations = _load_from_transmap(transmap_path)
    
    if not operations:
        # No operations found in transmap
        return None
    
    package_manager = _detect_package_manager()
    
    # Generate reverse commands (in reverse order - undo most recent first)
    reverse_commands = []
    for op_line in reversed(operations):
        cmds = _reverse_operation(op_line, package_manager)
        if cmds:
            reverse_commands.extend(cmds)
    
    if not reverse_commands:
        # No reversible operations found
        return None
    
    script_dir = os.environ.get('SCRIPT_DIR', os.path.dirname(os.path.dirname(__file__)))
    
    lines = [
        "#!/bin/bash",
        "set -eo pipefail",
        f'SCRIPT_DIR="{script_dir}"',
        'source "$SCRIPT_DIR/libs/linuxtoys.lib"',
        'source "$SCRIPT_DIR/libs/helpers.lib"',
    ]
    
    # Check if we need sudo
    needs_sudo = any(
        cmd.strip().startswith("sudo ") for cmd in reverse_commands
    )
    
    if needs_sudo:
        lines.append("")
        lines.append("# Request sudo authorization")
        lines.append("sudo_rq")
    
    lines.append("")
    lines.append("# Reverse operations from failed script execution (in reverse order)")
    lines.extend(reverse_commands)
    lines.append("")
    lines.append('echo "Automatic reversion completed."')
    
    # Write temporary script
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", prefix="linuxtoys-auto-revert-", suffix=".sh", delete=False
        ) as temp_script:
            temp_script.write("\n".join(lines) + "\n")
            temp_path = temp_script.name
    except Exception:
        return None
    
    os.chmod(temp_path, 0o700)
    
    # Prepare return entry
    script_name_display = script_info.get("name", "Script")
    revert_name = (
        translations.get("auto_revert_action_name", "Auto-revert {name}")
        if translations
        else "Auto-revert {name}"
    ).format(name=script_name_display)
    
    return {
        "icon": script_info.get("icon", "application-x-executable"),
        "name": revert_name,
        "description": translations.get(
            "auto_revert_action_desc",
            "Automatically reverts components installed by this script before it failed.",
        )
        if translations
        else "Automatically reverts components installed by this script before it failed.",
        "repo": script_info.get("repo", ""),
        "path": temp_path,
        "is_script": True,
        "cleanup_path": temp_path,
    }
