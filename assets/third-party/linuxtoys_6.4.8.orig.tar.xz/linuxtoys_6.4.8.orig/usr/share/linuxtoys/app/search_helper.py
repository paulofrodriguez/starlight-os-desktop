"""
Search functionality for LinuxToys application.
Provides search capabilities across script names, descriptions, and categories.
Uses caching for improved performance during runtime.

Works transparently with both git-synced and bundled scripts:
- Scripts are sourced from parser.SCRIPTS_DIR which may be git-synced or bundled
- Automatically filters hidden directories (e.g., .git) from git-synced repos
- Includes local scripts from ~/.local/linuxtoys/scripts
"""

import os
import re
from . import parser
from .compat import (
    get_system_compat_keys, 
    script_is_compatible, 
    script_is_localized, 
    is_containerized, 
    script_is_container_compatible,
    should_show_optimization_script,
    get_revert_capability,
    should_enable_manual_revert,
)
from .lang_utils import detect_system_language
from .revert_helper import _get_executed_script_names


class ScriptCache:
    """
    Caches available scripts based on system compatibility.
    Built on app startup to provide fast searches without traversing directories.
    
    The cache stores:
    - All compatible scripts filtered by system compat keys
    - Locale-specific scripts
    - Container compatibility
    - Optimization script visibility state
    - Removable state (whether the script can currently be uninstalled)
    """
    
    def __init__(self):
        self.scripts = []  # List of cached script info dicts
        self.is_populated = False
        self.system_compat_keys = get_system_compat_keys()
        self.current_locale = detect_system_language()
        self.is_containerized = is_containerized()
        self._removable_cache = {}  # script_path -> bool
    
    def populate(self, translations=None):
        """
        Populate the cache with all available scripts for the current system.
        This should be called once on app startup.
        
        Args:
            translations: Dictionary of translations for script names/descriptions
        """
        if self.is_populated:
            return  # Already populated
        
        self.scripts = []
        self._removable_cache = {}
        scripts_dir = parser.SCRIPTS_DIR
        
        # Get all scripts from main directory recursively
        self._collect_scripts_from_directory(scripts_dir, translations)
        
        # Also get local scripts directory
        local_scripts_dir = f'{os.environ.get("HOME", "")}/.local/linuxtoys/scripts'
        if os.path.isdir(local_scripts_dir):
            self._collect_scripts_from_directory(local_scripts_dir, translations)
        
        # Pre-compute removable state for all cached scripts in one pass
        self._populate_removable_cache()
        
        self.is_populated = True
    
    def _collect_scripts_from_directory(self, directory_path, translations=None):
        """Recursively collect scripts from a directory."""
        if not os.path.isdir(directory_path):
            return
        
        # Get the set of scripts that should be hidden due to negation
        negated_scripts = parser._get_negated_scripts(directory_path, self.system_compat_keys)
        
        for item_name in os.listdir(directory_path):
            # Skip hidden directories and files (e.g., .git, .gitignore)
            # Important for git-synced scripts which include .git directory
            if item_name.startswith('.'):
                continue
            
            item_path = os.path.join(directory_path, item_name)
            
            if item_name.endswith('.sh') and os.path.isfile(item_path):
                # Check if this script is negated by another compatible script
                script_name_without_ext = os.path.splitext(item_name)[0]
                if script_name_without_ext in negated_scripts:
                    continue
                
                # Filter by compatibility and locale
                if not script_is_compatible(item_path, self.system_compat_keys):
                    continue
                if not script_is_localized(item_path, self.current_locale):
                    continue
                # Filter by container compatibility
                if self.is_containerized and not script_is_container_compatible(item_path):
                    continue
                # Filter optimization scripts based on installation state
                if not should_show_optimization_script(item_path):
                    continue
                
                # Parse script metadata
                defaults = {
                    'name': 'No Name',
                    'version': 'N/A',
                    'description': '',
                    'icon': 'application-x-executable',
                    'reboot': 'no',
                    'repo': '',
                    'is_new': False
                }
                script_info = parser._parse_metadata_file(item_path, defaults, translations)
                
                # Store the full path for later category extraction
                script_info['path'] = item_path
                
                # For local scripts, use filename if no name was found
                is_local_script = '.local/linuxtoys/scripts' in item_path
                if is_local_script and script_info['name'] == 'No Name':
                    script_info['name'] = os.path.splitext(item_name)[0]
                
                script_info['is_script'] = True
                script_info['is_subcategory'] = False
                self.scripts.append(script_info)
                
            elif os.path.isdir(item_path):
                # Recursively collect from subdirectories
                self._collect_scripts_from_directory(item_path, translations)
    
    def get_all_scripts(self):
        """Get all cached scripts."""
        return self.scripts.copy()
    
    def _populate_removable_cache(self):
        """
        Pre-compute the removable state for every cached script.
        
        This avoids repeatedly opening the registry file and re-reading each
        script's revert header while browsing categories or search results.
        """
        executed_names = _get_executed_script_names()
        
        for script_info in self.scripts:
            script_path = script_info.get('path', '')
            if not script_path or not os.path.isfile(script_path):
                self._removable_cache[script_path] = False
                continue
            
            script_name = script_info.get('name', '')
            if not script_name:
                self._removable_cache[script_path] = False
                continue
            
            revert_capability = get_revert_capability(script_path, self.system_compat_keys)
            if revert_capability == 'no':
                self._removable_cache[script_path] = False
                continue
            
            if revert_capability == 'internal':
                self._removable_cache[script_path] = script_name in executed_names
                continue
            
            if not should_enable_manual_revert(script_path, self.system_compat_keys):
                self._removable_cache[script_path] = False
                continue
            
            self._removable_cache[script_path] = script_name in executed_names
    
    def refresh_removable_cache(self):
        """
        Refresh only the removable state of cached scripts.

        This re-reads the action registry without rebuilding script metadata,
        compatibility information, translations, or categories.
        """
        self._removable_cache.clear()
        self._populate_removable_cache()
    
    def is_script_removable(self, script_info):
        """
        Return the cached removable state for a script.
        
        Falls back to a direct (slower) computation if the script is not in the
        cache, which is useful for scripts created after the cache was built.
        """
        script_path = script_info.get('path', '')
        if script_path in self._removable_cache:
            return self._removable_cache[script_path]
        
        # Fallback for scripts not yet in cache (e.g. newly created local scripts)
        if not script_info.get('is_script') or not script_path or not os.path.isfile(script_path):
            return False
        
        script_name = script_info.get('name', '')
        if not script_name:
            return False
        
        revert_capability = get_revert_capability(script_path, self.system_compat_keys)
        if revert_capability == 'no':
            return False
        
        executed_names = _get_executed_script_names()
        if revert_capability == 'internal':
            return script_name in executed_names
        
        if not should_enable_manual_revert(script_path, self.system_compat_keys):
            return False
        
        return script_name in executed_names
    
    def update_removable_for_script(self, script_info):
        """
        Recompute the removable state for a single script.
        """
        script_path = script_info.get("path", "")
        if not script_path:
            return

        # Remove the previous value so is_script_removable() performs
        # a direct registry-based computation instead of returning stale data.
        self._removable_cache.pop(script_path, None)
        self._removable_cache[script_path] = self.is_script_removable(script_info)
    
    def invalidate(self):
        """Invalidate the cache, forcing repopulation on next use."""
        self.is_populated = False
        self.scripts = []
        self._removable_cache = {}
    
    def refresh_for_translations(self, translations):
        """
        Invalidate and repopulate the cache with new translations.
        Call this when language settings change.
        
        Args:
            translations: Updated dictionary of translations
        """
        self.invalidate()
        self.populate(translations)


class CategoryCache:
    """
    Caches all categories and their scripts for fast navigation.
    Built on app startup to provide fast category/script loading without traversing directories.
    
    The cache stores:
    - All top-level categories with their metadata
    - All scripts for each category
    - Subcategory information
    - All filtered by system compatibility
    """
    
    def __init__(self):
        self.categories = []  # List of cached category info dicts
        self.scripts_by_category = {}  # Dict mapping category path -> list of scripts
        self.is_populated = False
        self.system_compat_keys = get_system_compat_keys()
        self.current_locale = detect_system_language()
        self.is_containerized = is_containerized()
    
    def populate(self, translations=None):
        """
        Populate the cache with all categories and their scripts.
        This should be called once on app startup.
        
        Args:
            translations: Dictionary of translations for category/script names
        """
        if self.is_populated:
            return  # Already populated
        
        self.categories = []
        self.scripts_by_category = {}
        
        # Get all categories
        self.categories = parser.get_categories(translations)
        
        # Pre-populate scripts for each category and nested subcategories
        for category in self.categories:
            category_path = category.get('path', '')
            if category_path:
                scripts = parser.get_scripts_for_category(category_path, translations)
                self.scripts_by_category[category_path] = scripts
                
                # Also pre-populate scripts for nested subcategories
                for script in scripts:
                    if script.get('is_subcategory'):
                        subcategory_path = script.get('path', '')
                        if subcategory_path:
                            subscripts = parser.get_scripts_for_category(subcategory_path, translations)
                            self.scripts_by_category[subcategory_path] = subscripts
        
        self.is_populated = True
    
    def get_categories(self):
        """Get all cached categories."""
        return self.categories.copy()
    
    def get_scripts_for_category(self, category_path):
        """Get scripts for a specific category from cache.
        
        If the path is not in the cache, returns an empty list.
        The caller should have a fallback to parser.get_scripts_for_category().
        """
        return self.scripts_by_category.get(category_path, []).copy()
    
    def invalidate(self):
        """Invalidate the cache, forcing repopulation on next use."""
        self.is_populated = False
        self.categories = []
        self.scripts_by_category = {}
    
    def refresh_for_translations(self, translations):
        """
        Invalidate and repopulate the cache with new translations.
        Call this when language settings change.
        
        Args:
            translations: Updated dictionary of translations
        """
        self.invalidate()
        self.populate(translations)


class SearchResult:
    """Represents a single search result."""
    
    def __init__(self, item_info, match_type, match_score):
        self.item_info = item_info
        self.match_type = match_type  # 'name', 'description', 'category'
        self.match_score = match_score  # Higher score = better match
        
    def __lt__(self, other):
        # Sort by score (descending), then by name
        if self.match_score != other.match_score:
            return self.match_score > other.match_score
        return self.item_info.get('name', '').lower() < other.item_info.get('name', '').lower()


class SearchEngine:
    """Main search engine for LinuxToys."""
    
    def __init__(self, translations=None, script_cache=None):
        self.translations = translations or {}
        self.system_compat_keys = get_system_compat_keys()
        self.current_locale = detect_system_language()
        self.script_cache = script_cache or ScriptCache()
        
    def update_translations(self, translations):
        """
        Update translations for the search engine and invalidate cache.
        The cache will be repopulated with new translations in background.
        
        Args:
            translations: Dictionary of translations
        """
        self.translations = translations
        
        # Invalidate cache and repopulate with new translations in a background thread
        def refresh_cache():
            try:
                self.script_cache.refresh_for_translations(translations)
            except Exception as e:
                print(f"Error refreshing search cache for translations: {e}")
        
        import threading
        threading.Thread(target=refresh_cache, daemon=True).start()
        
    def set_cache(self, script_cache):
        """Set the script cache to use."""
        self.script_cache = script_cache
        
    def search(self, query, max_results=50):
        """
        Search for scripts matching the query using the cache.
        Returns results grouped by category for improved UX.
        
        Args:
            query: Search string
            max_results: Maximum number of results to return (per category)
            
        Returns:
            List of category groups: [
                {
                    'category_name': 'Category Name',
                    'category_path': '/path/to/category',
                    'best_match_score': 95,  # Highest score in this category
                    'scripts': [SearchResult, ...]  # Sorted by relevance
                },
                ...
            ]
            Sorted by best_match_score (descending)
        """
        if not query or len(query.strip()) < 2:
            return []
            
        query = query.strip().lower()
        results = []
        
        # Search through cached scripts (much faster than directory traversal)
        self._search_cached_scripts(query, results)
        
        # Group results by category
        grouped = self._group_results_by_category(results, max_results)
        
        return grouped
    
    def _group_results_by_category(self, results, max_results_per_category):
        """
        Group search results by category and sort appropriately.
        Scripts without a proper category are kept as 'Uncategorized' without a header.
        
        Args:
            results: List of SearchResult objects
            max_results_per_category: Max results to include per category
            
        Returns:
            List of category group dicts sorted by best match score
        """
        # Group results by category
        category_groups = {}
        
        for result in results:
            category_name = self._extract_category_name(result.item_info.get('path', ''))
            
            # Root-level scripts go to 'Uncategorized' group (no category header will be shown)
            if category_name == 'Other':
                category_name = self.translations.get('uncategorized', 'Uncategorized')
                category_path = 'uncategorized'
            else:
                category_path = result.item_info.get('path', '').rsplit('/', 1)[0] if '/' in result.item_info.get('path', '') else 'Uncategorized'
            
            if category_path not in category_groups:
                category_groups[category_path] = {
                    'category_name': category_name,
                    'category_path': category_path,
                    'best_match_score': 0,
                    'scripts': [],
                    'show_header': category_name != self.translations.get('uncategorized', 'Uncategorized')  # Don't show header for uncategorized
                }
            
            # Update best match score for this category
            if result.match_score > category_groups[category_path]['best_match_score']:
                category_groups[category_path]['best_match_score'] = result.match_score
            
            category_groups[category_path]['scripts'].append(result)
        
        # Sort scripts within each category by relevance
        for group in category_groups.values():
            group['scripts'].sort()
            group['scripts'] = group['scripts'][:max_results_per_category]
        
        # Convert to list and sort by best match score (descending)
        grouped_list = list(category_groups.values())
        grouped_list.sort(key=lambda g: g['best_match_score'], reverse=True)
        
        return grouped_list
    
    def _extract_category_name(self, script_path):
        """
        Extract a human-readable category name from the script path.
        Handles nested categories properly.
        
        Examples:
        - '/scripts/utils/some_script.sh' -> 'Utils' (or translated)
        - '/scripts/drivers/nvidia/nvidia_installer.sh' -> 'Nvidia' (or 'Drivers - Nvidia' if no leaf translation)
        - '/scripts/pdefaults.sh' -> 'Other' (root-level, no category)
        
        Uses translations when available (using folder names as keys).
        Falls back to title-cased path components with hierarchy separators.
        
        Args:
            script_path: Full path to the script
            
        Returns:
            Category name or 'Other' if not determinable or root-level script
        """
        if not script_path:
            return 'Other'
        
        # Split the path and find the category parts
        parts = script_path.split('/')
        
        # Look for script directory indicators
        if 'scripts' in parts:
            idx = parts.index('scripts')
            
            # Extract all directory parts after 'scripts' (excluding the .sh file)
            category_parts = []
            for i in range(idx + 1, len(parts)):
                part = parts[i]
                if part.endswith('.sh'):
                    # Found the script file, stop collecting category parts
                    break
                category_parts.append(part)
            
            if not category_parts:
                # Root-level script with no category directory
                return 'Other'
            
            # Construct full nested category path for grouping key
            full_category_path = '/'.join(category_parts)
            
            # Try to get translated name for the full nested path first
            translated_name = self.translations.get(full_category_path)
            if translated_name:
                return translated_name
            
            # Try to get translated name for the leaf (last) category
            leaf_category = category_parts[-1]
            translated_name = self.translations.get(leaf_category)
            if translated_name:
                return translated_name
            
            # Fallback: build display name with hierarchy separators
            # For nested categories, show as "Parent - Leaf" or "Parent > Leaf"
            display_parts = [p.replace('_', ' ').title() for p in category_parts]
            display_name = ' - '.join(display_parts)
            return display_name
        
        return 'Other'
    
    def _search_cached_scripts(self, query, results):
        """Search through cached scripts."""
        if not self.script_cache.is_populated:
            return  # Cache not ready
        
        for script_info in self.script_cache.get_all_scripts():
            score = self._calculate_match_score(query, script_info, 'script')
            if score > 0:
                results.append(SearchResult(script_info, 'script', score))
        
        # Add "Create New Script" option as a searchable item
        self._search_create_new_script_option(query, results)
    
    def _search_categories(self, query, results):
        """Search through categories."""
        categories = parser.get_categories(self.translations)
        
        for category in categories:
            # Skip script categories (we'll handle them in cached scripts)
            if category.get('is_script', False):
                continue
                
            score = self._calculate_match_score(query, category, 'category')
            if score > 0:
                # Add category type marker for UI handling
                category_copy = category.copy()
                category_copy['type'] = 'category'
                results.append(SearchResult(category_copy, 'category', score))
    
    def _search_create_new_script_option(self, query, results):
        """Search for the 'Create New Script' option."""
        # Always include the create script option since the directory can be created on demand
        # We don't need to check if the directory exists as it will be created when needed
        
        local_scripts_dir = f'{os.environ.get("HOME", "")}/.local/linuxtoys/scripts'
        create_script_name = self.translations.get('create_new_script_name', 'Create New Script')
        create_script_desc = self.translations.get('create_new_script_desc', 'Create a new local script')
        
        create_script_item = {
            'name': create_script_name,
            'description': create_script_desc,
            'icon': 'document-new',
            'path': local_scripts_dir,
            'is_script': False,
            'is_subcategory': False,
            'is_create_script': True
        }
        
        # Calculate match score for the create script option
        score = self._calculate_match_score(query, create_script_item, 'create_script')
        if score > 0:
            results.append(SearchResult(create_script_item, 'create_script', score))

    def _calculate_match_score(self, query, item_info, item_type):
        """
        Calculate relevance score for a search match.
        Higher score = more relevant.
        """
        name = item_info.get('name', '').lower()
        description = item_info.get('description', '').lower()
        score = 0
        
        # Check for 'new' keyword match (English or translated)
        translated_new = self.translations.get('new_spec_key', 'new').lower() 
        if (query == 'new' or query == translated_new) and item_info.get('is_new', False):
            score += 90  # High score for exact 'new' keyword match
        
        # Exact name match gets highest score
        if query == name:
            score += 100
        # Name starts with query
        elif name.startswith(query):
            score += 80
        # Query appears in name
        elif query in name:
            score += 60
        
        # Description matches (lower priority than name)
        if query in description:
            score += 30
            
        # Boost scores for certain item types
        if item_type == 'category':
            score += 10  # Categories slightly boosted for navigation
        elif item_type == 'create_script':
            score += 15  # Create script option gets a good boost for utility
            
        # Boost for shorter names (more specific matches)
        if score > 0 and len(name) < 20:
            score += 5
            
        # Additional scoring for word boundary matches
        if score > 0:
            # Check if query matches word boundaries (more relevant)
            word_pattern = r'\b' + re.escape(query) + r'\b'
            if re.search(word_pattern, name):
                score += 20
            elif re.search(word_pattern, description):
                score += 10
                
        return score


def create_search_engine(translations=None, script_cache=None):
    """
    Factory function to create a search engine instance.
    
    Args:
        translations: Dictionary of translations
        script_cache: Optional ScriptCache instance (creates one if not provided)
        
    Returns:
        SearchEngine instance configured with the cache
    """
    if script_cache is None:
        script_cache = ScriptCache()
    return SearchEngine(translations, script_cache)
